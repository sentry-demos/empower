import json
import sentry_sdk
from sentry_sdk.integrations.aws_lambda import AwsLambdaIntegration

sentry_sdk.init(
    dsn="https://558b9a3c35e7837cca0ab34319223ef0@o87286.ingest.us.sentry.io/4508729393217536",
    # Add data like request headers and IP for users, if applicable;
    # see https://docs.sentry.io/platforms/python/data-management/data-collected/ for more info
    send_default_pii=True,
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for tracing.
    traces_sample_rate=1.0,
    # Set profiles_sample_rate to 1.0 to profile 100%
    # of sampled transactions.
    # We recommend adjusting this value in production.
    profiles_sample_rate=1.0,
    integrations=[
        AwsLambdaIntegration(),
    ],
)

def lambda_handler(event, context):
    records = event["Records"]
    record_count = len(records)
    print(f"Received {record_count} records in this invocation.")

    for record in records:
        # Each record is an SQS message
        body = record['body']
        print(f"Processing message body: {body}")
       # Parse the message as JSON
        try:
            message = json.loads(body)
        except json.JSONDecodeError:
            raise ValueError("Message body is not valid JSON.")

        # Check for negative inventory
        inventory_list = message.get("inventory")
        if not isinstance(inventory_list, list):
            raise ValueError("Inventory field is missing or not a list.")

        for idx, quantity in enumerate(inventory_list):
            if quantity < 0:
                raise ValueError(
                    f"Negative inventory detected for index {idx}: {quantity}"
                )

    return {"statusCode": 200, "body": f"Processed {record_count} record(s)"}



    # for record in event['Records']:
    #         try:
    #             message_body = json.loads(record['body'])  # Parse JSON body
    #             order_id = message_body.get("order_id")
    #             status = message_body.get("status")

    #             print(f"Order ID: {order_id}, Status: {status}")

    #         except json.JSONDecodeError:
    #             print(f"Invalid JSON format: {record['body']}")

    #     return {"statusCode": 200, "body": "Batch processed"}
